Exe Lock and Boxed Tool v2.6

Squeeze Any Application into a Single Binary,

This is a utility that "packs" your original application into a single all-sufficient executable binary. ActiveX controls, dynamic libraries, and just all kinds of files that your original application depends on - all can be "squeezed" in that file. The packer creates an individual work environment for the application - with data, swap file, etc. So, when the application runs, it doesn't require any external resources or special privileges.

Lock and Password Protect Any Programs on PCs,

Exe Lock and Boxed is an easy-to-use program that allows you to password protect programs and applications. It works on the program files that are 32/64bit Windows XP/7/8/10/11 executables. Usually, those files are stored on your system with the default “.EXE” file type.
﻿
Password Protect Any EXE: Any executable program can be locked with password, such as chat software, multimedia players, games, etc.
License Control: Support hardware binding mode, generate exclusive password for each computer. Unauthorized computers will not be able to run the protected EXE。

License Control on Any PC,
When protecting a program, Exe Lock and Boxed modifies the binary executable itself, so that it first asks for a password and runs the program only if a valid password has been entered. It does not change the Registry database, nor does it save the password in hidden files or disk sectors. Also, it does not matter whether you protect the program on your hard drive or a floppy disk.

Through the hardware binding mode, the protected EXE can only be run on the authorized computer, which can effectively prevent the EXE file from being distributed without authorization.

Lock Software with Password,
Exe Lock and Boxed is ideal in these situations, as it allows you to lock and password protect executables, so that only those who know the password will be able to run the programs.

Safe and efficient
Exe Lock and Boxed is safe and efficient. Unlike other protection software, it does not run in the background to provide its functionality. With the other software, which claims to be password protected, an intruder can simply kill the protection program or remove it from the startup group to disable the entire mechanism. Note, that Exe Lock and Boxed protects programs, not icons so that it remains locked even if you run it from the plain command line.

FAQs,
Will the protection still work if I copy the protected executable file to a different machine?
A: Yes, the protection will still work fine.

After I protected a program, what should I do if my antivirus software shows that it has been infected by a virus?
A: Do not panic.  Exe Lock and Boxed is not a virus. Antivirus software is correct in detecting that the executable file has been changed. However, this change adds the password checking functionality of  Exe Lock and Boxed and does not spread as a virus would.
